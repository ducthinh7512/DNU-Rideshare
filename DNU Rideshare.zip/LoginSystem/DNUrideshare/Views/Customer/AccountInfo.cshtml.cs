﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNUrideshare.Views.Customer;

public class AccountInfo : PageModel
{
    public void OnGet()
    {
        
    }
}