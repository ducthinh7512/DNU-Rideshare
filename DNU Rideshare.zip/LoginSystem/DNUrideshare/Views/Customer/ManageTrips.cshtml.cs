﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNUrideshare.Views.Customer;

public class ManageTrips : PageModel
{
    public void OnGet()
    {
        
    }
}