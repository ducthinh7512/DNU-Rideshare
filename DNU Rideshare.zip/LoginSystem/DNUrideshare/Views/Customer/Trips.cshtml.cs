﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNUrideshare.Views.Customer;

public class Trips : PageModel
{
    public void OnGet()
    {
        
    }
}