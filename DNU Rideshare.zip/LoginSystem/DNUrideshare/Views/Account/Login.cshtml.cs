﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNUrideshare.Views.Account;

public class Login : PageModel
{
    public void OnGet()
    {
        
    }
}