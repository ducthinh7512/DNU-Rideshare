﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNUrideshare.Views.Account;

public class CustomerDashboard : PageModel
{
    public void OnGet()
    {
        
    }
}