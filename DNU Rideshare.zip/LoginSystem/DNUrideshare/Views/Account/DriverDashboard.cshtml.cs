﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNUrideshare.Views.Account;

public class DriverDashboard : PageModel
{
    public void OnGet()
    {
        
    }
}