﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNUrideshare.Views.Account;

public class AdminDashboard : PageModel
{
    public void OnGet()
    {
        
    }
}