﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNUrideshare.Views.Account;

public class PostTrip : PageModel
{
    public void OnGet()
    {
        
    }
}