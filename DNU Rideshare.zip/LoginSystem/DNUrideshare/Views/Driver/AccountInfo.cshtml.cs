﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNUrideshare.Views.Account;

public class AccountInfo : PageModel
{
    public void OnGet()
    {
        
    }
}