﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNUrideshare.Views.Account;

public class PostTripSuccess : PageModel
{
    public void OnGet()
    {
        
    }
}