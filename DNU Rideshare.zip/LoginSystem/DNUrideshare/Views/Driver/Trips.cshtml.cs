﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNUrideshare.Views.Account;

public class Trips : PageModel
{
    public void OnGet()
    {
        
    }
}