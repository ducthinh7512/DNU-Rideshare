﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNUrideshare.Views.Account;

public class EditAccount : PageModel
{
    public void OnGet()
    {
        
    }
}