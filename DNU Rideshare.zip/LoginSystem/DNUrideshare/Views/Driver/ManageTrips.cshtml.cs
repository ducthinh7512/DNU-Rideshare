﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DNUrideshare.Views.Account;

public class ManageTrips : PageModel
{
    public void OnGet()
    {
        
    }
}